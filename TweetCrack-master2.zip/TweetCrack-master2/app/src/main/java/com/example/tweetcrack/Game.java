package com.example.tweetcrack;

import com.android.volley.RequestQueue;

public class Game {

//    public Tweet(RequestQueue q) {
//        queue = q;
//    }
}
